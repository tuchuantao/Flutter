main(List<String> args) {
    print(sum(20, 30));
}

// 返回值的类型是可以省略(开发中不推荐)
int sum(int num1, int num2) {
  return num1 + num2;
}
