// import 'dart:io';
// import 'dart:isolate';
// import 'dart:async';
// import 'dart:math';

// 1.系统的库: import 'dart:库的名字';

import 'dart:math';

main(List<String> args) {
  final num1 = 20;
  final num2 = 30;
  print(min(num1, num2));
}

