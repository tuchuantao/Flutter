class UserInfo {
  String nickname;
  int level;
  String imageURL;

  UserInfo(this.nickname, this.level, this.imageURL);
}